# AgriNova AI — Android Starter

এই ZIP-এ Kotlin + Jetpack Compose starter project আছে:
- বাংলা/English language switcher
- Gallery থেকে গাছের ছবি নির্বাচন
- গাছের নাম ও লক্ষণ লেখার ঘর
- Firebase AI Logic/Gemini image analysis-এর নমুনা
- নির্বাচিত ভাষায় AI রিপোর্ট

## চালানোর ধাপ
1. Android Studio (JDK 17 সহ) ইনস্টল করুন এবং ZIP extract করে project খুলুন।
2. Firebase Console-এ project তৈরি করুন এবং Android app package দিন: `com.agrinova.ai`
3. Firebase থেকে `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন।
4. Firebase AI Logic setup করুন; model availability, API enablement, quota, App Check ও billing settings যাচাই করুন।
5. Gradle Sync করুন, তারপর Run দিয়ে পরীক্ষা করুন।
6. APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## গুরুত্বপূর্ণ
এটি starter source; এখানে APK build বা device testing করা হয়নি। Firebase setup ছাড়া AI কাজ করবে না। SDK/API ও model availability পরিবর্তিত হলে dependency/import/model name আপডেট লাগতে পারে। API key source code-এ hardcode করবেন না। Free tier সীমাহীন নয়। AI diagnosis নিশ্চিত চিকিৎসা নয়; কীটনাশকের আগে পণ্যের লেবেল ও কৃষি কর্মকর্তার পরামর্শ অনুসরণ করুন।
