package com.agrinova.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgriNovaApp() }
    }
}

private enum class AppLanguage { BN, EN }

@Composable
private fun AgriNovaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("agrinova_settings", Context.MODE_PRIVATE) }
    var language by remember {
        mutableStateOf(if (prefs.getString("language", "bn") == "en") AppLanguage.EN else AppLanguage.BN)
    }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var plantName by remember { mutableStateOf("") }
    var symptoms by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val bn = language == AppLanguage.BN

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        imageUri = uri
        result = ""
        error = ""
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF247A3D))) {
        Scaffold { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("AgriNova AI", style = MaterialTheme.typography.headlineMedium)
                        Text(if (bn) "স্মার্ট কৃষি সহায়ক" else "Smart Plant Doctor")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = {
                            language = AppLanguage.BN
                            prefs.edit().putString("language", "bn").apply()
                        }) { Text("বাংলা") }
                        TextButton(onClick = {
                            language = AppLanguage.EN
                            prefs.edit().putString("language", "en").apply()
                        }) { Text("English") }
                    }
                }

                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (bn) "গাছের রোগ শনাক্তকরণ" else "Plant Disease Diagnosis",
                            style = MaterialTheme.typography.titleLarge)
                        Text(if (bn) "পাতা, ফল বা গাছের আক্রান্ত অংশের পরিষ্কার ছবি দিন."
                            else "Select a clear photo of the affected leaf, fruit, or plant.")
                        Button(onClick = { picker.launch("image/*") }, Modifier.fillMaxWidth()) {
                            Text(if (bn) "ছবি নির্বাচন করুন" else "Select Image")
                        }
                        imageUri?.let { uri ->
                            AsyncImage(model = uri,
                                contentDescription = if (bn) "গাছের ছবি" else "Plant image",
                                modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp))
                        }
                        OutlinedTextField(plantName, { plantName = it },
                            label = { Text(if (bn) "গাছের নাম (ঐচ্ছিক)" else "Plant name (optional)") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(symptoms, { symptoms = it },
                            label = { Text(if (bn) "লক্ষণ লিখুন (ঐচ্ছিক)" else "Describe symptoms (optional)") },
                            modifier = Modifier.fillMaxWidth(), minLines = 2)
                        Button(
                            enabled = imageUri != null && !busy,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                val uri = imageUri ?: return@Button
                                busy = true; result = ""; error = ""
                                (context as? ComponentActivity)?.lifecycleScope?.launch {
                                    try {
                                        val bitmap = loadBitmap(context, uri)
                                        result = PlantDiagnosisService().diagnose(
                                            bitmap, plantName, symptoms, if (bn) "Bengali" else "English"
                                        )
                                    } catch (e: Exception) {
                                        error = if (bn)
                                            "বিশ্লেষণ করা যায়নি। Firebase সেটআপ, ইন্টারনেট ও কোটা পরীক্ষা করুন।"
                                        else "Analysis failed. Check Firebase setup, internet, and quota."
                                    } finally { busy = false }
                                }
                            }
                        ) {
                            Text(when {
                                busy && bn -> "বিশ্লেষণ হচ্ছে..."
                                busy -> "Analyzing..."
                                bn -> "AI দিয়ে বিশ্লেষণ করুন"
                                else -> "Analyze with AI"
                            })
                        }
                    }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                if (result.isNotBlank()) Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (bn) "বিশ্লেষণের ফলাফল" else "Diagnosis Report",
                            style = MaterialTheme.typography.titleLarge)
                        Text(result)
                        Text(if (bn) "এটি AI-এর সম্ভাব্য বিশ্লেষণ, নিশ্চিত রোগ নির্ণয় নয়."
                            else "This is an AI-assisted assessment, not a confirmed diagnosis.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text(if (bn) "AI-এর পরামর্শ যাচাই না করে কীটনাশক ব্যবহার করবেন না."
                    else "Verify recommendations before applying pesticides.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun loadBitmap(context: Context, uri: Uri): Bitmap =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, _, _ -> decoder.isMutableRequired = false }
    } else {
        @Suppress("DEPRECATION")
        MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
    }

private class PlantDiagnosisService {
    private val model = Firebase.ai(backend = GenerativeBackend.googleAI())
        .generativeModel(modelName = "gemini-2.5-flash")

    suspend fun diagnose(bitmap: Bitmap, plantName: String, symptoms: String, language: String): String {
        val prompt = """
            You are a cautious plant-health assistant for farmers in Bangladesh.
            Reply entirely in $language. Keep scientific disease names in Latin.
            Plant name: ${plantName.ifBlank { "Unknown" }}
            User symptoms: ${symptoms.ifBlank { "Not provided" }}
            Inspect the image and report: plant identification if possible; possible disease,
            pest, nutrient deficiency or non-disease cause; visible evidence and alternatives;
            immediate low-risk actions; prevention and monitoring; additional information needed.
            Do not claim certainty from an image alone. Do not invent pesticide doses, product
            registrations or unsupported treatments. If unclear, say so and suggest consulting
            a local agricultural officer for serious cases.
        """.trimIndent()
        val response = model.generateContent(content {
            image(bitmap)
            text(prompt)
        })
        return response.text ?: "No analysis returned. Please try again."
    }
}
